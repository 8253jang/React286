package web.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Step04AxiosApplication {

    public static void main(String[] args) {
        SpringApplication.run(Step04AxiosApplication.class, args);
    }

}
