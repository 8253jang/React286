import React from 'react';

const NotFound = () => {
    return (
        <div>
            Not fo
        </div>
    );
};

export default NotFound;