package web.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSocketStompApplicationTests {

    @Test
    void contextLoads() {
    }

}
