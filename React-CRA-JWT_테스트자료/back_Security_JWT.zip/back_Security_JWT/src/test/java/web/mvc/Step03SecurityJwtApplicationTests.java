package web.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Step03SecurityJwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
